package com.cg.lab2.service;

import com.cg.lab2.dao.BookAuthorDao;
import com.cg.lab2.dao.BookAuthorDaoImpl;

public class BookAuthorServiceImpl implements BookAuthorService {

	BookAuthorDao dao = new BookAuthorDaoImpl();
	@Override
	public void getAllBooks() {
		
	}

	@Override
	public void getBookByAuthor() {
		
	}

	@Override
	public void getByPrice() {
		
	}

	@Override
	public void getAuthorByBook() {
		
	}

	
}
