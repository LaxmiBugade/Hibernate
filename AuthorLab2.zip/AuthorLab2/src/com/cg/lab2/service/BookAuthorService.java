package com.cg.lab2.service;

public interface BookAuthorService {

	public void getAllBooks();

	public void getBookByAuthor();

	public void getByPrice();

	public void getAuthorByBook();

}
