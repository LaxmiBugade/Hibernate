package com.cg.lab2.dao;

public interface BookAuthorDao {

	public void getAllBooks();

	public void getBookByAuthor();

	public void getByPrice();

	public void getAuthorByBook();
	
//	Methods to begin and commit transactions
	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
