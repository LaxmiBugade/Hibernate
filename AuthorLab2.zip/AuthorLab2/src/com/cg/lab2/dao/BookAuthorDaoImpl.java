package com.cg.lab2.dao;

import javax.persistence.EntityManager;


public class BookAuthorDaoImpl implements BookAuthorDao {

private EntityManager entityManager;
	
	public BookAuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit(); //commit transaction
	}
	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin(); //begin transaction
	}
	
	@Override
	public void getAllBooks() {
		
	}

	@Override
	public void getBookByAuthor() {
		
	}

	@Override
	public void getByPrice() {
		
	}

	@Override
	public void getAuthorByBook() {
		
	}
}
