package com.cg.lab2.entities;

public class BookAuthor {

//	variables
	private int bookId;
	private int authorId;
	
//	Getters & setters
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	
	
}
