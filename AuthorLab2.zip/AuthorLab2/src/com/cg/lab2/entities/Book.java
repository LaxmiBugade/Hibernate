package com.cg.lab2.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity 
public class Book {

	//variables
	@Id
	private int bookId;
	private String bookName;
	private float price;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "book_author", joinColumns = { @JoinColumn(name = "authorId") }, inverseJoinColumns = { @JoinColumn(name = "bookId") })
	private Set<Author> authors = new HashSet<>();
	
	//Getters and setters
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public Set<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	//constructors
	public Book() {
	}

	public Book(int isbn, String title, float price) {
		this.bookId = isbn;
		this.bookName = title;
		this.price = price;
	}	
}
