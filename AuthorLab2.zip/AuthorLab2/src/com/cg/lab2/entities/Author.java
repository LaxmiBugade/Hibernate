package com.cg.lab2.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Author {

	//variables
	@Id
	private int ID;
	private String name;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="authors")
	private Set<Book> books = new HashSet<>();
	
	//Getters & setters
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Book> getBooks() {
		return books;
	}
	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	
	//Constructors
	public Author(){}
	public Author(int iD, String name) {
		ID = iD;
		this.name = name;
	}
}
