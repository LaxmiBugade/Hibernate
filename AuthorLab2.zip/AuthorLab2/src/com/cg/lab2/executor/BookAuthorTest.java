package com.cg.lab2.executor;

import java.util.Scanner;

import com.cg.lab2.service.BookAuthorService;
import com.cg.lab2.service.BookAuthorServiceImpl;

public class BookAuthorTest {

	public static void main(String[] args) {
		int choice=0;
		Scanner sc = new Scanner(System.in);
		BookAuthorService bas = new BookAuthorServiceImpl();
		
		do{
			System.out.println("1:Display All Books\n2:Display All Book By Author"+
					"\n3:Display By price\n4:Display Author By Book\n5:Exit");
			System.out.println("Enter your choice:");
			choice = sc.nextInt();
			switch(choice){
			case 1: bas.getAllBooks();
				break;
				
			case 2: bas.getBookByAuthor();
				break;
				
			case 3: bas.getByPrice();
				break;
				
			case 4: bas.getAuthorByBook();
				break;
				
			case 5: System.exit(0);
				
				
			default: System.out.println("Wrong Choice");
				break;
			}
		}while(choice != 5);
	}
}
