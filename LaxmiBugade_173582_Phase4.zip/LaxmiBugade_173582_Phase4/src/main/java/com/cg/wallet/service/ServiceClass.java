package com.cg.wallet.service;

import java.util.List;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.dao.CustomerDaoImpl;
import com.cg.wallet.exception.IdNotFoundException;
import com.cg.wallet.exception.InsufficientBalanceException;

public class ServiceClass implements ServiceInterface{
	
	CustomerDaoImpl dao = new CustomerDaoImpl();
	
	//overriding method to validate name
	public boolean validName(String name) {
		boolean isValid = false;
		if(name.matches(NAMEPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate mobile number
	public boolean validNumber(String number) {
		boolean isValid = false;
		if(number.matches(NUMBERPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	public boolean validEmail(String email) {
		boolean isValid = false;
		if(email.matches(EMAILPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate amount
//	@Override
	public boolean validAmount(String amount) {
		boolean isValid = false;
		if(amount.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate account number
	public boolean validAccount(String account) {
		boolean isValid = false;
		if(account.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}
	
	//method to validate customer id
	public boolean validId(String id) {
		boolean isValid = false;
		if(id.matches(CUSTOMERID))
			isValid = true;
			
		return isValid;
	}
	
	//overriding method to insert record into database
	public boolean insert(Customer c){
		boolean b = dao.insert(c);
		return b;
	}

	//method to show balance
	public String showBalance(long custId)throws IdNotFoundException {
		return dao.showBalance(custId);
	}

	//method to deposit money
	public String deposite(String custId, String amount)throws IdNotFoundException {
		try {
			String amt = dao.deposite(custId,amount);
			return amt;
		} catch (Exception e) {
			throw new IdNotFoundException(e.getMessage());
		}
	}

	//method to withdraw money
	public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException {
		try{
			String amt = dao.withdraw(custId,amount);
			return amt;
		}catch(Exception e){
			throw new IdNotFoundException(e.getMessage());
		}
	}

	//method to fund transfer
	public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException {
		try {
			String amt = dao.fundTransfer(senderId, receiverId, amount);
			return amt;
		} catch (Exception e) {
			throw new InsufficientBalanceException(e.getMessage());
		}
	}

	public void printTransaction(){
		dao.printTransaction();
	}
}
