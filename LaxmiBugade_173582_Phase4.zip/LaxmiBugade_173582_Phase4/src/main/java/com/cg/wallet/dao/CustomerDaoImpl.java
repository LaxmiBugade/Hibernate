package com.cg.wallet.dao;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.exception.IdNotFoundException;
import com.cg.wallet.exception.InsufficientBalanceException;

public class CustomerDaoImpl implements CustomerDao {

	ApplicationContext context;
	Customer cust = new Customer();
	Transaction[] txn;
	int idx;
	
	public CustomerDaoImpl() {
		context = new ClassPathXmlApplicationContext("wallet.xml");
	}
	
	//insert into table
	public boolean insert(Customer c){
		//generating random no. for customerId an set
		long custId = (long)(Math.random()*1000);
		c.setCustId(custId);
		customerEntry.put(custId, c);
		System.out.println("Account created successfully.");
		System.out.println("Your details are as following:");
		System.out.println("Customer Id: "+c.getCustId()+"\tName: "+c.getName()+
				"\tMobile: "+c.getMobile()+"\tEmail: "+c.getEmail()+"\tBalance: "+c.getBalance());
		
		//creating reference to the transaction 
		txn = new Transaction[10];
		txn[idx++] = new Transaction("CR",c.getBalance(),c.getBalance());
		return true;
	}

	//method to display balance 
	public String showBalance(long custId)throws IdNotFoundException{
		String balance = null;
		if(customerEntry.containsKey(custId)) {
			Customer c1 = new Customer();
			c1 = customerEntry.get(custId);
			balance = c1.getBalance();
		}
		return balance;
	}
	
	//method to deposit
	public String deposite(String custId, String amount)throws IdNotFoundException {
		String balance;
		if(customerEntry.containsKey(Long.parseLong(custId))) {
			Customer c1 = new Customer();
			c1 = customerEntry.get(Long.parseLong(custId));
		
			long balance1 = Long.parseLong(amount)+(Long.parseLong(c1.getBalance()));
			balance = String.valueOf(balance1);
			
			transactionEntry.put(cust.getCustId(), cust.getBalance());
			txn[idx++] = new Transaction("CR",amount,cust.getBalance());
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		
		return balance;
	}

	//method to withdraw
	public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException {
		String balance;
		if(customerEntry.containsKey(Long.parseLong(custId))) {
			cust.setCustId(Long.parseLong(custId));
			long balance1 = Long.parseLong(cust.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1-= Long.parseLong(amount);
				balance = String.valueOf(balance1);
				transactionEntry.put(cust.getCustId(), cust.getBalance());
				txn[idx++] = new Transaction("DR",amount,cust.getBalance());
			}else{
				throw new InsufficientBalanceException("You don't have sufficient balance to withdraw");
			}
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		return balance;
	}

	//method to fund transfer
	public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException {
		String balance = null;
		if(customerEntry.containsKey(senderId) && customerEntry.containsKey(receiverId)) {
			cust.setCustId(Long.parseLong(senderId));
			long balance1 = Long.parseLong(cust.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1-= Long.parseLong(amount);
				balance = String.valueOf(balance1);
				cust.setCustId(Long.parseLong(receiverId));
				long receiverBalance = Long.parseLong(cust.getBalance());
				long rcvBal = receiverBalance + Long.parseLong(amount);
				cust.setBalance(String.valueOf(receiverBalance));
				transactionEntry.put(cust.getCustId(), cust.getBalance());
				txn[idx++] = new Transaction("FT",amount,cust.getBalance());
			}else{
				throw new InsufficientBalanceException("You don't have enough balance to withdraw");
			}
		}else {
			throw new IdNotFoundException("customer Id is not found");
		}
		return balance;
	}

	//print all transactions
	public void printTransaction(){
		for(int i=0; i<idx; i++)
			System.out.println(txn[i].print());
	}
}
