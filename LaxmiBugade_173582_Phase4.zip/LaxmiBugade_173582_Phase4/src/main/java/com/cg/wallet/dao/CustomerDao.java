package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.wallet.bean.Customer;

public interface CustomerDao {

	Map<Long,Customer> customerEntry = new HashMap<Long,Customer>();
	
	Map<Long,String> transactionEntry =new HashMap<Long,String>();
	
	//methods related to CRUD defined in CustomerDaoImpl class
	public boolean insert(Customer c);
}
