package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;

public interface ServiceInterface {
	
	Customer c = new Customer();
	
	//defining constants
	public String NAMEPATTERN = "[A-Z][a-z]{5,12}";
	public String NUMBERPATTERN = "[0-9]{10}";
	public String EMAILPATTERN = "[a-zA-z0-9]{1,12}[@][a-zA-Z]{4,10}[.][a-zA-Z]{3}";
	public String AMOUNTPATTERN = "[0-9]{3,6}[.]?[0-9]{1,4}";
	public String ACCOUNTPATTERN = "[0-9]{10}";
	public String CUSTOMERID = "[0-9]{2,4}";
	
	//declaring methods
	public boolean validName(String name);
	public boolean validNumber(String number);
	public boolean validEmail(String email);
	public boolean validAmount(String amount);
	public boolean validAccount(String account);
	public boolean validId(String id);
	
	//DB related task
	public boolean insert(Customer c);

}
