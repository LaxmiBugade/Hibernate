package com.cg.employee.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.entity.Employee;
import com.cg.employee.exception.IdNotFoundException;
import com.cg.employee.service.EmployeeService;

@RestController
public class EmployeeController {

	//Service Injection
	@Autowired
	private EmployeeService service;
	
	
	@GetMapping("/hi")
	public String get() {
		return "Hello, Welcome to spring boot";
	}
	
	//Method to get all employees
	@GetMapping("/employees")
	public Iterable<Employee> getAll() {
		return service.getAll();
	}
	
	//Method to save employee
	@PostMapping(path ="/addEmployee", consumes = "application/json")
	public String saveEmployee(@RequestBody Employee emp) {
	 service.saveEmployee(emp);
	 return "Employee Saved";
	 }


	//	Method to get employee by id
	@GetMapping(name="/getbyid" ,produces= "application/json")
	public Employee getById(@RequestParam("id") String id) {
		Employee emp = service.getById(id);
		return emp;
	}
	
	//	Method to get employee by department
	@GetMapping(name="/getbydept" ,produces= "application/json")
	public Employee getByDept(@RequestParam("department") String department) {
		Employee emp = service.getByDept(department);
		return emp;
	}
	
	
	//Method to update employee
	@PutMapping(path ="/updateemployee", consumes = "application/json")
	public Employee updateEmployee(@PathVariable("id") String id, @RequestBody Employee emp) {
		return service.updateEmployee(emp, id);
	}
	
	//Method to delete employee
	@DeleteMapping(path ="/delete/{id}")
	public String deleteEmployee(@PathVariable("id") String id) throws IdNotFoundException {
		return service.deleteEmployee(id);
	}

}
