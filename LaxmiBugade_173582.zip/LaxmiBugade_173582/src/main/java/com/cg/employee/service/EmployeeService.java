package com.cg.employee.service;

import com.cg.employee.entity.Employee;
import com.cg.employee.exception.IdNotFoundException;

public interface EmployeeService {
	
    void saveEmployee(Employee emp);
	
    Employee getById(String empId);
	
	Iterable<Employee> getAll();
	
	public String deleteEmployee(String id) throws IdNotFoundException;

	public Employee updateEmployee(Employee emp, String id);

	Employee getByDept(String department);
	
}
