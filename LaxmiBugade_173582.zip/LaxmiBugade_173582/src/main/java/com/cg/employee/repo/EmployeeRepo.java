package com.cg.employee.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.employee.entity.Employee;

public interface EmployeeRepo extends CrudRepository<Employee, Integer> {

	Employee getByDept(String department);
	
}
