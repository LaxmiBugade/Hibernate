package com.cg.employee.exception;

public class IdNotFoundException extends Exception {

	public IdNotFoundException(String message) {
		super(message);
	}
}
