package com.cg.employee.service;

import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.entity.Employee;
import com.cg.employee.exception.IdNotFoundException;
import com.cg.employee.repo.EmployeeRepo;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	//Injection
	@Autowired
	private EmployeeRepo repo;

	//Method to save employee
	@Override
	public void saveEmployee(Employee emp) {
		repo.save(emp);
	}

	//Method to get employee by id
	@Override
	public Employee getById(String empId)throws NoSuchElementException {
		int id;
		try {
			id = Integer.parseInt(empId);
		}catch(NoSuchElementException e) {
			throw new NoSuchElementException("Employee id not found");
		}
		return repo.findById(id).get();
	}

	//Method to get all employees
	@Override
	public Iterable<Employee> getAll() {
		return repo.findAll();
	}

	//Method to update employee
	@Override
	public Employee updateEmployee(Employee emp, String id) {
		emp.setEmpId(id);
		repo.save(emp);
		return emp;
	}

	//Method to delete employee
	@Override
	public String deleteEmployee(String empId) throws IdNotFoundException {
    	int id = Integer.parseInt(empId);
    	Employee e1 = repo.findById(id).get();
    	repo.delete(e1);
    	
	    return "Delete Successfully";
	    
	}

    //Method to get employee by department
	@Override
	public Employee getByDept(String department) {
		return repo.getByDept(department);
	}

}
