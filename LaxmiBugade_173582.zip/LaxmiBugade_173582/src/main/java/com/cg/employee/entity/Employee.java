package com.cg.employee.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {

	//variables declared
	@Id
	@GeneratedValue
	@Column(name="emp_id",length=20)
	private String empId;
	
	@Column(name="name",length=20)
	private String empName;
	
	@Column(length=20)
	private String designation;
	
	@Column(name="dept_name", length=25)
	private String empDept;
	
	@Column(length=8)
	private double salary;

	//Generated Getters & Setters
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmpDept() {
		return empDept;
	}

	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	//Constructors
	public Employee(String empId, String empName, String designation, String empDept, double salary) {
		this.empId = empId;
		this.empName = empName;
		this.designation = designation;
		this.empDept = empDept;
		this.salary = salary;
	}

	public Employee() {
	}
}
