package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaxmiBugade173582Application {

	public static void main(String[] args) {
		SpringApplication.run(LaxmiBugade173582Application.class, args);
	}

}
