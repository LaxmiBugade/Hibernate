import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{

  //to create new or edit customer
  @Input() customer : Customer;

  //to control update button
  @Input() isEditing : boolean;

  @Output() edited = new EventEmitter();
  
  //constructor to initialize customer
  constructor(private custService:CustomerService) { 
    this.customer = new Customer();
  }

  //insert customer data
  insert(){
    this.custService.insert(this.customer);
    this.customer = new Customer();
  }

  //update date
  update(){
    this.isEditing = false;
    this.customer = new Customer();
    this.edited.emit();
  }
}
