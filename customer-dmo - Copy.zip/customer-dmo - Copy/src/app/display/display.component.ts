import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  custArr : Customer[];
  customerToEdit:Customer;
  isEditing:boolean;

  constructor(private custService:CustomerService) { 
    this.custArr = [];
    this.customerToEdit = new Customer()
  }

  ngOnInit() {
    this.custArr = this.custService.display();
  }

  delete(index : number){
    this.custService.delete(index);
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.customerToEdit = this.custService.edit(id);
  }

  sortByName(){
    this.custService.sortByName();
  }

  sortByAmount(){
    this.custService.sortByAmount();
  }
}
