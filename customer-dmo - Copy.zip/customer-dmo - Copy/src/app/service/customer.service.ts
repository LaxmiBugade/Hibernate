import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
 
  custArr : Customer[];
  constructor(private routes:Router) { 
    this.custArr = [];
  }

  //to insert data into array
  insert(customer: Customer){
    customer.custId = Math.floor(Math.random()*100);
    this.custArr.push(customer);
    alert('Updated successfully!');
    this.routes.navigate(['/Display']);
  }

  //to display data stored into array
  display(){
    return this.custArr;
  }

  //to remove data from array
  delete(index:number){
    this.custArr.splice(index,1);
  }

  //to edit
  edit(id: number){
    return this.custArr.find(c => c.custId == id);
  }

  //to sort by name
  sortByName(){
    this.custArr.sort((a,b) => a.custName.localeCompare(b.custName.valueOf()));
    return this.custArr;
  }

  //to sort by amount
  sortByAmount(){
    this.custArr.sort((a,b) => a.insurance - b.insurance);
    return this.custArr;
  }

  //to search
  search(id: number){
    var result = this.custArr.find(c => c.custId == id);
    if(result == null)
      return null;
    else
      return result;
  }
}
