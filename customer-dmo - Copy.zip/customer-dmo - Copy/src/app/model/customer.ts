export class Customer{
    public custId: number;
    public custName: string;
    public email: string;
    public mobile: number;
    public insurance: number;
}