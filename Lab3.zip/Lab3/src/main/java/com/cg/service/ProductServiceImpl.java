package com.cg.service;


import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.cg.entity.Product;
import com.cg.repo.ProductDao;

@Path("/product")
public class ProductServiceImpl{
	 
	
	// URI:
    // /contextPath/servletPath/employees
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Product> getAllProduct() {
        List<Product> listOfProduct = ProductDao.getAllProduct();
        return listOfProduct;
    }
    
 // URI:
    // /contextPath/servletPath/employees
    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Product addProduct(Product p) {
        return ProductDao.addProduct(p);
    }

}
