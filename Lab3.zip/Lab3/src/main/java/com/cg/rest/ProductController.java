package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
@RequestMapping("api/v1")
public class ProductController {

	//Injecting repo
	@Autowired
	private ProductRepo repo;
	
	@GetMapping("/post")
	public ModelAndView showPostView() {
		return new ModelAndView("post","product",new Product());
	}
	
	// Add trainee details
		@RequestMapping(value = "/add", method = RequestMethod.POST)
		public ModelAndView userRegister(@ModelAttribute("product") Product product) {
			ModelAndView model = new ModelAndView("product");
			if (product != null) {
				repo.saveProduct(product);
			}
			return new ModelAndView("redirect:/getAll");
		}
		
		@GetMapping(value="/getAll",produces="application/json")
		public List<Product> getAll(){
			return repo.getAll();
		}
		
		@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class,
			javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class
		})
		public ModelAndView showError() {
			return new ModelAndView("error");
		}
}
