package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product_lab3")
public class Product {

	//Variables
	@Id
	@GeneratedValue
	private int prodId;
	
	@Column(length=20)
	private String prodName;
	
	@Column(length=20)
	private double prodPrice;
	
	//Getters & setters
	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	
	//Constructors
	public Product() {
	}

	

	public Product(int id, String name, double price) {
		super();
		this.prodId = id;
		this.prodName = name;
		this.prodPrice = price;
	}

	//toString()
	@Override
	public String toString() {
		return "Product [id=" + prodId + ", name=" + prodName + ", price=" + prodPrice + "]";
	}

	
}
