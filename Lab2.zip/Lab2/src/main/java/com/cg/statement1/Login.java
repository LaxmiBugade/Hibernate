package com.cg.statement1;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Login{
	
	//variables
	@NotEmpty(message="User name is mandatory")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String username;
	private String password;
	
	//Getters & setters
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}