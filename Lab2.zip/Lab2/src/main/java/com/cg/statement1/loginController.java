package com.cg.statement1;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/login")
public class loginController {

	// Checks if the user credentials are valid or not.
	@RequestMapping(value="checkLogin")
	public String checkLogin(@ModelAttribute ("user")
	@Valid Login userName,BindingResult result,Model model,Login login)
	{
	 //Logic to validate userName and password against database
	 if(result.hasErrors()) {
		 return "login";
	 }

	 else if(login.getUsername().equals("laxmi") && login.getPassword().equals("laxmi") )
	 {
	   return "loginSuccess"; 
	}else {
	 model.addAttribute("alert", "invalid password or username");
	 return "login";
	}
	 }
}
