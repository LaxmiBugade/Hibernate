package com.cg.wallet.dao;

import com.cg.wallet.bean.Customer;

public interface CustomerDao {

	public abstract void commitTransaction();

	public abstract void beginTransaction();
	
	//methods related to CRUD defined in CustomerDaoImpl class
	public boolean insert(Customer c);
	public void display();
}
