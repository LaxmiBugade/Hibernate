package com.cg.wallet.dao;

import com.cg.wallet.bean.Customer;

public interface CustomerDao {

	public void beginTransaction();
	public void commitTransaction();
	
	//methods related to CRUD defined in CustomerDaoImpl class
	public boolean insert(Customer c);
	public void display();
}
