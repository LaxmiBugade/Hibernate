package com.cg.wallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.exception.InsufficientBalanceException;

public class CustomerDaoImpl implements CustomerDao {

	private EntityManager entityManager;
	Transaction t;
	public CustomerDaoImpl() {
		//t = new Transaction();
		entityManager = JPAUTIL.getEntityManager();
	}
	
	//begin transaction
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	//commit transaction
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	
	//insert into table
	public boolean insert(Customer c){
		entityManager.persist(c); //insert customer record into Customer table
		String qry = "select max(c.custId) from Customer c";
		TypedQuery<Long> query = entityManager.createQuery(qry, Long.class);
		long custId = query.getSingleResult();
		
		Transaction trans = new Transaction(custId,"DT",c.getBalance());
		entityManager.persist(trans); //insert record into transaction table
		return true;
	}
	
	//display from table
	public void display(){
		entityManager=JPAUTIL.getEntityManager();
		Query query = entityManager.createQuery("SELECT c FROM Customer c");
		List<Customer> custList = query.getResultList();
		for (Customer customer : custList) {
			System.out.println(customer);
		}
	}

	//method to display balance 
	public String showBalance(String custId) {
		String balance = null;
		try{
			entityManager=JPAUTIL.getEntityManager();
			long id = Long.parseLong(custId);
			Customer custObj = entityManager.find(Customer.class, id);
			
			custObj = entityManager.find(Customer.class, id);
			balance = custObj.getBalance();
		
		}catch(NullPointerException e){
			System.out.println("Customer Id is not present");
		}
		return balance;
	}
	
	//method to deposit
	public String deposite(String custId, String amount) {
		String balance = null;
		try{
			entityManager=JPAUTIL.getEntityManager();
			Customer custObj = entityManager.find(Customer.class, Long.parseLong(custId));
			long balance1 = Long.parseLong(custObj.getBalance()) + Long.parseLong(amount);
			balance = String.valueOf(balance1);
			custObj.setBalance(balance);
			
			//update balance 
			custObj = entityManager.merge(custObj);
			balance = custObj.getBalance();
			
			
			//insert record into transaction table
			Transaction trans = new Transaction(Long.parseLong(custId),"DT",balance);
			entityManager.persist(trans); //insert record into transaction table
		
		}catch(NullPointerException e){
			System.out.println("Customer Id is not present");
		}
		return balance;
	}

	//method to withdraw
	public String withdraw(String custId, String amount)throws InsufficientBalanceException {
		String balance = null;
		try{
			//checking for sufficient balance
			entityManager=JPAUTIL.getEntityManager();
			long id = Long.parseLong(custId);
			Customer custObj = entityManager.find(Customer.class, id);
			long balance1 = Long.parseLong(custObj.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1 = balance1 - Long.parseLong(amount);
				balance = String.valueOf(balance1);
				custObj.setBalance(balance);
				
				//update balance 
				custObj = entityManager.merge(custObj);
				balance = custObj.getBalance();
				
				//insert record into transaction table
				Transaction trans = new Transaction(Long.parseLong(custId),"CT",balance);
				entityManager.persist(trans); //insert record into transaction table
			}else{
				throw new InsufficientBalanceException("You don't have enough balance to withdraw");
			}
		
		}catch(NullPointerException e){
			System.out.println("Customer Id is not present");
		}
		return balance;
	}

	public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException {
		String balance = null;
		try{
			//checking for sufficient balance
			entityManager=JPAUTIL.getEntityManager();
			Customer senderObj = entityManager.find(Customer.class, Long.parseLong(senderId));
			Customer receiverObj = entityManager.find(Customer.class, Long.parseLong(receiverId));
			long balance1 = Long.parseLong(senderObj.getBalance());
			if(balance1 > Long.parseLong(amount)){
				balance1 = balance1 - Long.parseLong(amount);
				balance = String.valueOf(balance1);
				senderObj.setBalance(balance);
				
				//update balance of sender
				senderObj = entityManager.merge(senderObj);
				balance = senderObj.getBalance();
				
				//insert sender record into transaction table
				Transaction trans = new Transaction(Long.parseLong(senderId),"CT",balance);
				entityManager.persist(trans); //insert record into transaction table
				
				//update balance of receiver
				long tmpCustBalance = Long.parseLong(receiverObj.getBalance()) + Long.parseLong(amount);
				receiverObj.setBalance(String.valueOf(tmpCustBalance));
				receiverObj = entityManager.merge(receiverObj);
				
				//insert receiver record into transaction table
				Customer cust = entityManager.find(Customer.class, Long.parseLong(receiverId));
				Transaction trans1 = new Transaction(Long.parseLong(receiverId),"DT",cust.getBalance());
				entityManager.persist(trans1); //insert record into transaction table
				
			}else{
				throw new InsufficientBalanceException("You don't have enough balance to withdraw");
			}
		
		}catch(NullPointerException e){
			System.out.println("Customer Id is not present");
		}
		return balance;
	}

	//print all transaction by customer id
	public List<Transaction> printTransaction(String cId) {
		long custId = Long.parseLong(cId);
		String qStr = "SELECT t FROM Transaction t where t.custId=:custID";
		TypedQuery<Transaction> query = entityManager.createQuery(qStr, Transaction.class);
		
		List<Transaction> custList = query.setParameter("custID", custId).getResultList();
		return custList;
	}
}
