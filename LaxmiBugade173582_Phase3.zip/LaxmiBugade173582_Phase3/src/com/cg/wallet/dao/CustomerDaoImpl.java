package com.cg.wallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.wallet.bean.Customer;

public class CustomerDaoImpl implements CustomerDao {

	private EntityManager entityManager;
	public CustomerDaoImpl() {
		
	}
	
	//insert into table
	public boolean insert(Customer c){
		entityManager.persist(c); //equivalent to insert
		return true;
	}
	
	//display from table
	public void display(){
		Query query = entityManager.createQuery("SELECT c FROM Customer c");
		List<Customer> custList = query.getResultList();
		for (Customer customer : custList) {
			System.out.println(customer);
		}
	}

	//method to display balance 
	public String showBalance(String custId) {
		String balance = null;
		try{
		entityManager=JPAUTIL.getEntityManager();
		long id = Long.parseLong(custId);
		Customer custObj = entityManager.find(Customer.class, id);
		long tmpId = custObj.getCustId();
		//System.out.println(tmpId);
		
		custObj = entityManager.find(Customer.class, id);
		balance = custObj.getBalance();
		
		}catch(NullPointerException e){
			System.out.println("Customer Id is not present");
		}
		return balance;
	}
	
	//begin transaction
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	//commit transaction
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
}
