package com.cg.wallet.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.exception.InsufficientBalanceException;
import com.cg.wallet.service.ServiceClass;

public class ExecutorMain {

	static Scanner scan = new Scanner(System.in);
	static Customer c = new Customer();
	static ExecutorMain mainClass = new ExecutorMain();
	static ServiceClass service = new ServiceClass();
		
	public static void main(String[] args){
			
		String name = null, mobile = null, email = null;
		System.out.println("Welcome to XYZ bank");
			
		int choice;
			
			do{
				System.out.println("1.Create New Account\t2:Display\t"
						+ "3:Show Balance\t4:Deposite\t5:Withdraw\t6:Fund Transfer\t"
						+ "7:Print Transaction\t8:Exit");
				System.out.println("Enter your choice:");
				choice = scan.nextInt();
				switch(choice){
				case 1: mainClass.createAccount();
						boolean success = service.insert(c);
						if(success)
							System.out.println("Customer account created successfully.");
						else
							System.out.println("Something got wrong.");
						break;
						
				case 2:	service.display();
						break;
						
				case 3: System.out.println("Enter customer id");
						String custId = mainClass.validCustId();
						String balance = service.showBalance(custId);
						System.out.println("Available Balance:"+balance);
						break;
					
				case 4: System.out.println("Enter customer id");
						custId = mainClass.validCustId();
						System.out.println("Enter amount to deposite");
						String amount = mainClass.valid();
						balance = service.deposite(custId, amount);
						System.out.println(amount+" amount deposited successfully");
						System.out.println("Available Balance: "+balance);
						break;
					
				case 5: String withdrawBalance = null;
						System.out.println("Enter customer id");
						custId = mainClass.validCustId(); 
						System.out.println("Enter amount to withdraw");
						amount = mainClass.valid();
						try{
							withdrawBalance = service.withdraw(custId,amount);
						}catch(InsufficientBalanceException e){
							System.out.println(e);
						}
						System.out.println(amount+" amount deposited successfully");
						System.out.println("Available Balance: "+withdrawBalance);
						break;
						
				case 6: String transferAmount = null;
						System.out.println("Enter sender id");
						String senderId = mainClass.validCustId();
						System.out.println("Enter reciepent id");
						String receiverId = mainClass.validCustId();
						System.out.println("Enter amount to withdraw");
						amount = mainClass.valid();
						try{
							transferAmount = service.fundTransfer(senderId,receiverId,amount);
						}catch(InsufficientBalanceException e){
							System.out.println(e);
						}
						System.out.println(amount+" amount trasfered successfully");
						System.out.println("Available Balance: "+transferAmount);
						break;
				
				case 7: System.out.println("Enter customer id to print transaction");
						custId = mainClass.validCustId();
						List<Transaction> transList = new ArrayList<>(); 
						transList = service.printTransaction(custId);
						for (Transaction transaction : transList) {
							System.out.println(transaction);
						}
						break;
						
				case 8: System.out.println("Visit Again..Thank you");
				System.exit(0);
						
				default: System.out.println("Wrong choice");
				}
			}while(choice!=7);
		}

		//validate customer id
		private String validCustId() {
			String id;
			while(true){
				id = scan.next();
				boolean isValid = service.validId(id);
				if(isValid)
					break;
				else
					System.out.println("Enter numbers only");
			}
			return id;
	    }
		
		//validate amount
		private String valid(){
			String amount;
			while(true){
				amount = scan.next();
				boolean isValid = service.validAmount(amount);
				if(isValid){
					break;
				}
				else{
					System.out.println("Enter numbers only");
				}
			}
			return amount;
		}

		public void createAccount(){
			
			//taking name from user
			System.out.println("Enter name");
			
			while(true){
				String name = scan.next();
				boolean isValid = service.validName(name);
				if(isValid){
					c.setName(name);
					break;
				}
				else{
					System.out.println("Enter name with first capital letter and minimum length 6");
				}
			}
			
			//taking mobile number from user
			System.out.println("Enter mobile number");
			while(true){
				String number = scan.next();
				boolean isValid = service.validNumber(number);
				if(isValid){
					c.setMobile(number);
					break;
				}
				else{
					System.out.println("Enter 10 digits number only");
				}
			}
			
			//taking email from user
			System.out.println("Enter email");
			while(true){
				String email = scan.next();
				boolean isValid = service.validEmail(email);
				if(isValid){
					c.setEmail(email);
					break;
				}
				else{
					System.out.println("Enter email in valid format");
				}
			}
			
			//taking amount from user
			System.out.println("Enter amount");
			while(true){
				String amount = scan.next();
				boolean isValid = service.validAmount(amount);
				if(isValid){
					c.setBalance(amount);
					break;
				}
				else{
					System.out.println("Enter numbers only");
				}
			}
		}
	
}
