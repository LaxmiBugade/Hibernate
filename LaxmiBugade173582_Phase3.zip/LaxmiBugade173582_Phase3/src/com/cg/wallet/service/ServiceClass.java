package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.CustomerDaoImpl;


public class ServiceClass implements ServiceInterface {
	
	CustomerDaoImpl dao = new CustomerDaoImpl();
	
	//overriding method to validate name
	@Override
	public boolean validName(String name) {
		boolean isValid = false;
		if(name.matches(NAMEPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate mobile number
	@Override
	public boolean validNumber(String number) {
		boolean isValid = false;
		if(number.matches(NUMBERPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	@Override
	public boolean validEmail(String email) {
		boolean isValid = false;
		if(email.matches(EMAILPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	@Override
	public boolean validAmount(String amount) {
		boolean isValid = false;
		if(amount.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate account number
	@Override
	public boolean validAccount(String account) {
		boolean isValid = false;
		if(account.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}
	
	//overriding method to insert record into database
	@Override
	public boolean insert(Customer c){
		return dao.insert(c);
	}
	
	//method to display data from customer table	
	public void display(){
		dao.display();
	}

	//method to validate customer id
	public boolean validId(String id) {
		boolean isValid = false;
		if(id.matches(CUSTOMERID))
			isValid = true;
		
		return isValid;
	}

	//method to show balance
	public String showBalance(String custId) {
		return dao.showBalance(custId);
	}
}
