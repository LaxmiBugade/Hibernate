package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service("traineeService")
public class TraineeService {

	//Injecting repo
	@Autowired
	TraineeRepo repo;
	
	//insert record into table
	public void save(Trainee t) {
		repo.save(t);
	}

	//Display all trainee list
	public Iterable<Trainee> getAllTrainee() {
		return repo.findAll();
	}

	//Display trainee by id
	public Trainee getTrainee(int traineeId) {
		return repo.findById(traineeId).get();
	}

	public void deleteTrainee(Trainee t) {
		 repo.delete(t);
	}

	
}
