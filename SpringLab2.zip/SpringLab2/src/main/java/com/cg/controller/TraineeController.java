package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	// Injecting service
	@Autowired
	TraineeService ts;
	Trainee trainee;

	// to open addTrainee form
	@RequestMapping(value = "/addTrainee", method = RequestMethod.GET)
	public String showAddPage(ModelMap model) {
		return "addTrainee";
	}

	// Add trainee details
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView userRegister(@ModelAttribute("trainee") Trainee trainee) {
		ModelAndView model = new ModelAndView("trainee");
		if (trainee != null) {
			ts.save(trainee);
		}
		return new ModelAndView("redirect:/getAllTrainee");
	}

	// Get list of all trainee
	@RequestMapping(value = "/getAllTrainee", method = RequestMethod.GET)
	public ModelAndView getAll() {
		ModelAndView model = new ModelAndView("getAllTrainee");
		model.addObject("list", ts.getAllTrainee());
		return model;
	}

	// display get trainee by id form
	@RequestMapping("/getTrainee")
	public String retrieveTrainee(Model model) {
		model.addAttribute("trainee");
		return "getTrainee";
	}

	// get trainee by id
	@RequestMapping("/getById")
	public String getTrainee(int traineeId, Model model) {
		Trainee trainee = ts.getTrainee(traineeId);
		model.addAttribute("trainee", trainee);
		return "getTrainee";
	}

	// To display delete Trainee form
	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee");
		return "deleteTrainee";
	}

	// delete trainee 
	@RequestMapping("delete")
	public ModelAndView delete(Model model, int traineeId) {
		trainee = ts.getTrainee(traineeId);

		model.addAttribute("trainee", trainee);
		if (trainee != null) {
			ts.deleteTrainee(trainee);
		} 
		return new ModelAndView("redirect:/getAllTrainee");
	}
	
	// function for modify trainee
		@RequestMapping("/modifyTrainee")
		public String modifyTrainee(Model model) {
			model.addAttribute("trainee", new Trainee());
			return "modifyTrainee";
		}

		// search for modify trainee
		@RequestMapping("/searchModify")
		public String searchTraineeModify(Model model, int traineeId) {
			trainee = ts.getTrainee(traineeId);

			model.addAttribute("trainee", trainee);
			return "modifyTrainee";
		}

		// updated successfully
		@RequestMapping(path = "modify")
		public String modify1(Model model, @ModelAttribute("trainee") Trainee trainee) {
			System.out.println(trainee);
			ts.save(trainee);

			model.addAttribute("trainee", trainee);
			return "trainee";
		}

}
