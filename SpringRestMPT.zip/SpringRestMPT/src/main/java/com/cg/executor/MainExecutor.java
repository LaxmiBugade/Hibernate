package com.cg.executor;

import java.util.List;

import com.cg.entity.Product;
import com.cg.repo.ProductRepoImpl;


public class MainExecutor {
	
	public static void main(String[] args) {
		ProductRepoImpl p =new ProductRepoImpl();
		Product pro = new Product();
		pro.setName("Pencil");
		pro.setPrice(20);
		p.saveProduct(pro);
		List<Product> productList = p.getAll();
		for (Product product : productList) {
			System.out.println(product);
		}
	}
}
