import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { Routes, RouterModule} from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { ToDoComponent } from './to-do/to-do.component';
import { LoginComponent } from './login/login.component';
import { CreateComponent } from './create/create.component';
import { EditComponent } from './edit/edit.component';

const routes: Routes=[
  
  {path:'', redirectTo:'/home',pathMatch:'full'},
  {path:'home',component: HomeComponent},
  {path:'toDo', component: ToDoComponent},
  {path:'login', component: LoginComponent},
  {path:'create',component: CreateComponent},
  {path:'edit',component: EditComponent},
  {path:'**', redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent, HomeComponent, ToDoComponent, LoginComponent, CreateComponent, EditComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes), FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
