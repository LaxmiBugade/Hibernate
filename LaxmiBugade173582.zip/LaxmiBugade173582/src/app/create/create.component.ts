import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TaskModel } from '../Model/TaskModel';
import { CreateService } from '../Service/create.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent {

 //to create new or edit task
 @Input() task : TaskModel;

 //to control update button
 @Input() isEditing : boolean;

 @Output() edited = new EventEmitter();
 
 //constructor to initialize 
 constructor(private taskService:CreateService) { 
   this.task = new TaskModel();
 }

 //insert task
 addTask(){
   this.taskService.addTask(this.task);
   this.task = new TaskModel();
 }

 //update date
//  update(){
//    this.isEditing = false;
//    this.task = new TaskModel();
//    this.edited.emit();
//  }
}
