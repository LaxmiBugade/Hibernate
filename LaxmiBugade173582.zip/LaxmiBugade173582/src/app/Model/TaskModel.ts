export class TaskModel{
    public taskId : number;
    public task : string;
    public status: string;
}