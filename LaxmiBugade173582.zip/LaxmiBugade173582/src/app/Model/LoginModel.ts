export class LoginModel{
    public email: string;
    public password: string;
}