import { Component, OnInit, Input } from '@angular/core';
import { LoginModel } from '../Model/LoginModel';
import { Router } from '@angular/router';
import { TaskModel } from '../Model/TaskModel';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent{

  taskArr : TaskModel[];

  constructor(private routes:Router) {
     //instantiate LoginModel
     this.taskArr = [];
  }

  update(id: number){
    return this.taskArr.find(t => t.taskId == id);
  }
}
