import { Component, OnInit, Input } from '@angular/core';
import { LoginModel } from '../Model/LoginModel';
import { LoginServiceService } from '../Service/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{

  //creating var of type LoginModel
  @Input() logModel: LoginModel;

   //to check username & password is blank
   @Input() isBothBlank : boolean;

   //to chack if only email entered
   @Input() isPasswordBlank : boolean;

  constructor(private logService: LoginServiceService) {
    //instantiate LoginModel
    this.logModel = new LoginModel();
   }

   login(){
    if(this.logModel.email == '' && 
      this.logModel.password == ''){
        this.isBothBlank = true;
    }
    else{
      this.isBothBlank = false;
    }

    if(this.logModel.email == 'admin@gmail.com' && 
      this.logModel.password == ''){
      this.isPasswordBlank = true;
    }
    else{
      this.isPasswordBlank = true;
    }
     this.logService.login(this.logModel);
   }
}
