import { Component, OnInit } from '@angular/core';
import { TaskModel } from '../Model/TaskModel';
import { CreateService } from '../Service/create.service';

@Component({
  selector: 'app-to-do',
  templateUrl: './to-do.component.html',
  styleUrls: ['./to-do.component.css']
})
export class ToDoComponent implements OnInit {
  taskArr : TaskModel[];
  taskToEdit:TaskModel;
  isEditing:boolean;

  constructor(private taskService:CreateService) { 
    this.taskArr = [];
    this.taskToEdit = new TaskModel()
  }

  ngOnInit() {
    this.taskArr = this.taskService.display();
  }

  delete(index : number){
    
    this.taskService.delete(index);
  }
}
