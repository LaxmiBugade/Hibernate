import { Injectable, Input } from '@angular/core';
import { Router } from '@angular/router';
import { LoginModel } from '../Model/LoginModel';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  logModel : LoginModel[];

  constructor(private routes:Router) {
     //instantiate LoginModel
     this.logModel = [];
  }

  //to check valid user
  login( logModel: LoginModel){
    //checking for correct credentials
    if(logModel.email == 'admin@gmail.com' && 
        logModel.password == '123456'){
            console.log("login");
            this.routes.navigate(['/toDo']);
    }//if close

    //checking for email and password blank
    else if(logModel.email == '' && 
    logModel.password == ''){
      this.routes.navigate(['/login']);
    }

    //checking only email is entered & password is blank
    else if(logModel.email == 'admin@gmail.com' && 
    logModel.password == ''){
      this.routes.navigate(['/login']);
    }

    else{
      console.log("login fail");
    }
  }
}
