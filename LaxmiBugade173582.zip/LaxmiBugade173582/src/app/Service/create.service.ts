import { Injectable } from '@angular/core';
import { TaskModel } from '../Model/TaskModel';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CreateService {

  taskArr : TaskModel[];
  constructor(private routes:Router) { 
    this.taskArr = [];
  }

  //to insert data into array
  addTask(task: TaskModel){
    console.log("task service");
    task.taskId = Math.floor(Math.random()*100);
    task.status = 'Incomplete';
    this.taskArr.push(task);
    alert('Updated successfully!');
    this.routes.navigate(['/toDo']);
  }

  //to display data stored into array
  display(){
    return this.taskArr;
  }

  // //to remove data from array
  delete(index:number){
    if(confirm('Do you want to delete task?')){
      this.taskArr.splice(index,1);
    }
  }

  // //to edit
  // edit(id: number){
  //   return this.custArr.find(c => c.custId == id);
  // }

  // //to sort by name
  // sortByName(){
  //   this.custArr.sort((a,b) => a.custName.localeCompare(b.custName.valueOf()));
  //   return this.custArr;
  // }

  // //to sort by amount
  // sortByAmount(){
  //   this.custArr.sort((a,b) => a.insurance - b.insurance);
  //   return this.custArr;
  // }

  // //to search
  // search(id: number){
  //   var result = this.custArr.find(c => c.custId == id);
  //   if(result == null)
  //     return null;
  //   else
  //     return result;
  // }
}
