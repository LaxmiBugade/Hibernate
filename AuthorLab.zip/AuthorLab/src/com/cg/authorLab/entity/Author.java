package com.cg.authorLab.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Author")
public class Author {
	
	//variables declared
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long authorId;
	private String firstName;
	private String middleName;
	private String lastName;
	private long phoneNo;
	
	//Getters & Setters
	public long getAuthorId() {
		return authorId;
	}
	public void setAuthorId(long authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	//toString() method
	@Override
	public String toString() {
		return "AuthorId=" + authorId + "\tFirstName=" + firstName
				+ "\tMiddleName=" + middleName + "\tLastName=" + lastName
				+ "\tPhoneNo=" + phoneNo;
	}

	
}
