package com.cg.authorLab.author;

import java.util.Scanner;

import com.cg.authorLab.entity.Author;
import com.cg.authorLab.service.AuthorService;
import com.cg.authorLab.service.AuthorServiceImpl;

public class AuthorExecuter {

	public static void main(String[] args) {
		int choice = 0;
		Scanner scan = new Scanner(System.in);
		AuthorService as = new AuthorServiceImpl();
		Author a = new Author();

		do {
			System.out
					.println("1:Insert\n2:Update\n3:Delete\n4:Display\n5:Exit");
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter first name");
				String fname = scan.next();
				a.setFirstName(fname);
				System.out.println("Enter middle name");
				String sname = scan.next();
				a.setMiddleName(sname);
				System.out.println("Enter last name");
				String lname = scan.next();
				a.setLastName(lname);
				System.out.println("Enter phone no");
				long phone = scan.nextLong();
				a.setPhoneNo(phone);
				as.insert(a);
				System.out.println("Author inserted successfully");
				as.getAllAuthors();
				break;

			case 2:
				System.out.println("Enter author Id to update");
				int authorId = scan.nextInt();
				System.out.println("Enter first name to update");
				String name = scan.next();
				as.update(authorId,name);
				System.out.println("Updated successfully");
				System.out.println(as.getById(a.getAuthorId()));
				break;

			case 3:
				System.out.println("Enter author Id to delete");
				authorId = scan.nextInt();
				Author author = as.getById(authorId);
				as.delete(author);
				System.out.println("Deleted successfully");
				as.getAllAuthors();
				break;

			case 4:
				System.out.println("Enter author Id to display data");
				authorId = scan.nextInt();
				a.setAuthorId(authorId);
				System.out.println(as.getById(a.getAuthorId()));
				break;

			case 5: System.exit(0);
				break;

			default:
				System.out.println("Wrong choice");
			}
		} while (choice != 5);
	}
}
