package com.cg.authorLab.service;

import com.cg.authorLab.entity.Author;

public interface AuthorService {

	//Methods related to CRUD operations defined in AuthoeServiceImpl class
	void insert(Author a);

	void update(long authorId, String authorName);

	void delete(Author a);

	Author getById(long id);

	void getAllAuthors();

}
