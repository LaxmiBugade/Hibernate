package com.cg.authorLab.service;

import com.cg.authorLab.entity.Author;

public interface AuthorService {

	//Methods related to CRUD operations defined in AuthoeServiceImpl class
	void insert(Author a);

	void update(Author a);

	void delete(Author a);

	void display(long id);

}
