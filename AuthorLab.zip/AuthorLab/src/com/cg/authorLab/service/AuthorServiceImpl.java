package com.cg.authorLab.service;

import com.cg.authorLab.dao.AuthorDao;
import com.cg.authorLab.dao.AuthorDaoImpl;
import com.cg.authorLab.entity.Author;

public class AuthorServiceImpl implements AuthorService {

	//dao class object initialization
	AuthorDao adao = new AuthorDaoImpl();
	
	//method to insert record into table
	@Override
	public void insert(Author a) {
		adao.beginTransaction();
		adao.insert(a);
		adao.commitTransaction();
	}

	//	method to update table
	@Override
	public void update(Author a) {
		adao.beginTransaction();
		adao.update(a);
		adao.commitTransaction();
	}

//	method to delete record from table
	@Override
	public void delete(Author a) {
		adao.beginTransaction();
		adao.delete(a);
		adao.commitTransaction();
	}

//	method to display record by id
	@Override
	public void display(long id) {
		adao.display(id);
	}

	
}
