package com.cg.authorLab.dao;

import com.cg.authorLab.entity.Author;

public interface AuthorDao {

//	Methods related to CRUD operations defined in AuthoeServiceImpl class
	void insert(Author a);

	void update(Author a);

	void delete(Author a);

	void display(long id);
	
//	Methods to begin and commit transactions
	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
