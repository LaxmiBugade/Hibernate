package com.cg.authorLab.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.authorLab.entity.Author;

public class AuthorDaoImpl implements AuthorDao{

	private EntityManager entityManager;
	
	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void insert(Author a) {
		entityManager.persist(a); //insert record into author table
	}

	@Override
	public void update(long authorId, String authorName) {
		Author authorObj = entityManager.find(Author.class, authorId);
		authorObj.setFirstName(authorName);
		authorObj = entityManager.merge(authorObj); //update firstName
	}

	@Override
	public void delete(Author a) {
		entityManager.remove(a); //remove record from author table
	}

	@Override
	public Author getById(long id) {
		//Author a = new Author();
		return entityManager.find(Author.class, id); //select record by id
		//System.out.println(a);
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit(); //commit transaction
	}
	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin(); //begin transaction
	}

	@Override
	public void getAllAuthors() {
		String qStr = "SELECT author FROM Author author";
		TypedQuery<Author> query = entityManager.createQuery(qStr, Author.class);
		List<Author> authorList = query.getResultList();
		for (Author a : authorList) {
			System.out.println(a);
		}
	}

}
