package com.cg.authorLab.dao;

import javax.persistence.EntityManager;
import com.cg.authorLab.entity.Author;

public class AuthorDaoImpl implements AuthorDao{

	private EntityManager entityManager;
	
	public AuthorDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void insert(Author a) {
		entityManager.persist(a); //insert record into author table
	}

	@Override
	public void update(Author a) {
		entityManager.merge(a); //update firstName
	}

	@Override
	public void delete(Author a) {
		entityManager.remove(a); //remove record from author table
	}

	@Override
	public void display(long id) {
		entityManager.find(Author.class, id); //select record by id
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit(); //commit transaction
	}
	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin(); //begin transaction
	}

}
