package com.cg.wallet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.wallet.dao.WalletRepoImpl;
import com.cg.wallet.entity.Customer;
import com.cg.wallet.exception.IdNotFoundException;
import com.cg.wallet.exception.InsufficientBalanceException;

@Service
public class WalletServiceImpl implements WalletService{

	@Autowired
	WalletRepoImpl dao;
	
	//overriding method to validate name
	public boolean validName(String name) {
		boolean isValid = false;
		if(name.matches(NAMEPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate mobile number
	public boolean validNumber(String number) {
		boolean isValid = false;
		if(number.matches(NUMBERPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate email
	public boolean validEmail(String email) {
		boolean isValid = false;
		if(email.matches(EMAILPATTERN))
			isValid = true;
		
		return isValid;
	}

	
	//overriding method to validate amount
	public boolean validAmount(String amount) {
		boolean isValid = false;
		if(amount.matches(AMOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}

	//overriding method to validate account number
	public boolean validAccount(String account) {
		boolean isValid = false;
		if(account.matches(ACCOUNTPATTERN))
			isValid = true;
		
		return isValid;
	}
	
	//method to validate customer id
	public boolean validId(String id) {
		boolean isValid = false;
		if(id.matches(CUSTOMERID))
			isValid = true;
			
		return isValid;
	}
	
	//overriding method to insert record into database
	public boolean insert(Customer c){
//		dao.beginTransaction();
		boolean b = dao.insert(c);
//		dao.commitTransaction();
		return b;
	}
	
	//method to display data from customer table	
	public List<Customer> display(){
		return dao.display();
	}

	//method to show balance
	public String showBalance(String custId)throws IdNotFoundException {
		return dao.showBalance(custId);
	}

	//method to deposit money
	public String deposite(String custId, String amount)throws IdNotFoundException {
		try {
//			dao.beginTransaction();
			String amt = dao.deposite(custId,amount);
//			dao.commitTransaction();
			return amt;
		} catch (Exception e) {
//			dao.commitTransaction();
			throw new IdNotFoundException(e.getMessage());
		}
	}

	//method to withdraw money
	public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException {
		try{
//			dao.beginTransaction();
			String amt = dao.withdraw(custId,amount);
//			dao.commitTransaction();
			return amt;
		}catch(Exception e){
//			dao.commitTransaction();
			throw new IdNotFoundException(e.getMessage());
		}
	}

	//method to fund transfer
	public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException {
		try {
//			dao.beginTransaction();
			String amt = dao.fundTransfer(senderId, receiverId, amount);
//			dao.commitTransaction();
			return amt;
		} catch (Exception e) {
//			dao.commitTransaction();
			throw new InsufficientBalanceException(e.getMessage());
		}
	}

//	public List<Transaction> printTransaction(String custId)throws IdNotFoundException {
//		return (List<Transaction>) dao.printTransaction(custId);
//	}
}
