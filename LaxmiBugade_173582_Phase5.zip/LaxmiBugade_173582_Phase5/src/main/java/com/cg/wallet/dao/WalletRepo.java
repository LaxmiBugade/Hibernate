package com.cg.wallet.dao;

import java.util.List;

import com.cg.wallet.entity.Customer;

public interface WalletRepo {

	//methods related to CRUD defined in CustomerDaoImpl class
	public boolean insert(Customer c);
	public List<Customer> display();
}
