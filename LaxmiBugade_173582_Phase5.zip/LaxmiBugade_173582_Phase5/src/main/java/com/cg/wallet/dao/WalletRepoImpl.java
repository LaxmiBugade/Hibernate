package com.cg.wallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.wallet.entity.Customer;
import com.cg.wallet.exception.IdNotFoundException;
import com.cg.wallet.exception.InsufficientBalanceException;


@Repository
public class WalletRepoImpl implements WalletRepo {

	@PersistenceContext(unitName="SpringJpa")
	private EntityManager em;
	
	//insert into table
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean insert(Customer c) {
		em.persist(c);
		return true;
	}

	//display from table
	public List<Customer> display(){
		return em.createQuery("from Customer_jpa").getResultList();
	}

	//method to display balance 
	public String showBalance(String custId)throws IdNotFoundException{
		String balance = null;
//		return em.find(Customer.class, custId);
//		entityManager=JPAUTIL.getEntityManager();
//			long id = Long.parseLong(custId);
//			Customer custObj;
//			try{
//				custObj = entityManager.find(Customer.class, id);
//				balance = custObj.getBalance();
//			}catch(NullPointerException e){
//				throw new IdNotFoundException("Customer Id is not present");
//			}
//			
			return balance;
		}
		
		//method to deposit
		public String deposite(String custId, String amount)throws IdNotFoundException {
			String balance = null;
//			entityManager=JPAUTIL.getEntityManager();
//			
//			try{
//				Customer custObj = entityManager.find(Customer.class, Long.parseLong(custId));
//				long balance1 = Long.parseLong(custObj.getBalance()) + Long.parseLong(amount);
//				balance = String.valueOf(balance1);
//				custObj.setBalance(balance);
//				
//				//update balance 
//				custObj = entityManager.merge(custObj);
//				balance = custObj.getBalance();
//				
//				
//				//insert record into transaction table
//				Transaction trans = new Transaction(Long.parseLong(custId),"CT",balance);
//				entityManager.persist(trans); //insert record into transaction table
//			
//			}catch(NullPointerException e){
//				throw new IdNotFoundException("Customer Id is not present");
//			}
			return balance;
		}

		//method to withdraw
		public String withdraw(String custId, String amount)throws InsufficientBalanceException,IdNotFoundException {
			String balance = null;
//			try{
//				//checking for sufficient balance
//				entityManager=JPAUTIL.getEntityManager();
//				long id = Long.parseLong(custId);
//				Customer custObj = entityManager.find(Customer.class, id);
//				long balance1 = Long.parseLong(custObj.getBalance());
//				if(balance1 > Long.parseLong(amount)){
//					balance1 = balance1 - Long.parseLong(amount);
//					balance = String.valueOf(balance1);
//					custObj.setBalance(balance);
//					
//					//update balance 
//					custObj = entityManager.merge(custObj);
//					balance = custObj.getBalance();
//					
//					//insert record into transaction table
//					Transaction trans = new Transaction(Long.parseLong(custId),"DT",balance);
//					entityManager.persist(trans); //insert record into transaction table
//				}else{
//					throw new InsufficientBalanceException("You don't have enough balance to withdraw");
//				}
//			
//			}catch(NullPointerException e){
//				throw new IdNotFoundException("Customer Id is not present");
//			}
			return balance;
		}

		public String fundTransfer(String senderId, String receiverId, String amount) throws InsufficientBalanceException, IdNotFoundException {
			String balance = null;
//			try{
//				//checking for sufficient balance
//				entityManager=JPAUTIL.getEntityManager();
//				Customer senderObj = entityManager.find(Customer.class, Long.parseLong(senderId));
//				Customer receiverObj = entityManager.find(Customer.class, Long.parseLong(receiverId));
//				long balance1 = Long.parseLong(senderObj.getBalance());
//				if(balance1 > Long.parseLong(amount)){
//					balance1 = balance1 - Long.parseLong(amount);
//					balance = String.valueOf(balance1);
//					senderObj.setBalance(balance);
//					
//					//update balance of sender
//					senderObj = entityManager.merge(senderObj);
//					balance = senderObj.getBalance();
//					
//					//insert sender record into transaction table
//					Transaction trans = new Transaction(Long.parseLong(senderId),"DT",balance);
//					entityManager.persist(trans); //insert record into transaction table
//					
//					//update balance of receiver
//					long tmpCustBalance = Long.parseLong(receiverObj.getBalance()) + Long.parseLong(amount);
//					receiverObj.setBalance(String.valueOf(tmpCustBalance));
//					receiverObj = entityManager.merge(receiverObj);
//					
//					//insert receiver record into transaction table
//					Customer cust = entityManager.find(Customer.class, Long.parseLong(receiverId));
//					Transaction trans1 = new Transaction(Long.parseLong(receiverId),"CT",cust.getBalance());
//					entityManager.persist(trans1); //insert record into transaction table
//					
//				}else{
//					throw new InsufficientBalanceException("You don't have enough balance to withdraw");
//				}
//			
//			}catch(NullPointerException e){
//				throw new IdNotFoundException("Customer Id is not present");
//			}
			return balance;
		}

		//print all transaction by customer id
//		public List<Transaction> printTransaction(String cId)throws IdNotFoundException {
//			entityManager=JPAUTIL.getEntityManager();
//			List<Transaction> custList;
//			
//			long custId = Long.parseLong(cId);
//			Customer custObj = entityManager.find(Customer.class, custId);
//			try{
//			if(custObj.equals(null)){
//				throw new IdNotFoundException("Customer Id is not present");
//			}else{
//			String qStr = "SELECT t FROM Transaction t where t.custId=:custID";
//			TypedQuery<Transaction> query = entityManager.createQuery(qStr, Transaction.class);
//			
//			custList = query.setParameter("custID", custId).getResultList();
//			}
//			}catch(Exception e){throw new IdNotFoundException("Customer Id is not present");}
//			return custList;
//		}
}
