package com.cg.wallet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction_jpa")
public class Transaction {
	
	//declaring constants 
	@Id
	@GeneratedValue
	public int transId;
	
	@Column(length=20)
	public String type;
	
	@Column(length=20)
	private String amount;
	
	@Column(length=20)
	private String balance;
	
	//constructores
	public Transaction(){
		
	}
	
	public Transaction(int id,String type,String amount, String balance) {
		this.transId = id;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	//to print all transaction
	public String print(){
		return (type+"\t"+amount+"\t"+balance);
	}
}
